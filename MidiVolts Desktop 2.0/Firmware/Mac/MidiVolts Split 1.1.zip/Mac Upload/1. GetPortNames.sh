#!/usr/bin/env bash

ls /dev/tty.*
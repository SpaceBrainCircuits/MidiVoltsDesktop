#!/usr/bin/env bash

screen /dev/tty.usbmodem1A12101 1200